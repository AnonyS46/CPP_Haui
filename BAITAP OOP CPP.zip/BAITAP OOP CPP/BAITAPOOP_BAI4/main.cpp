#include <iostream>
#include<string>
#include<stdio.h>0

using namespace std;
class XeHoi
{

private:
    string NhanHieu;
    string KieuDang;
    string MauSon;
    int  year;
    string XuatXu;
    long Price;
public:
    void Nhap()
    {
        fflush(stdin);
        cout<< "Nhap Nhan Hieu:"; getline(cin,NhanHieu);
        fflush(stdin);
        cout<< "Nhap Kieu Dang:"; getline(cin,KieuDang);
        fflush(stdin);
        cout<< "Nhap Mau Son:"; getline(cin,MauSon);
        cout<< "Nhap Nam San Xuat:"; cin>>year;
        fflush(stdin);
        cout<< "Nhap Noi San Xuat:"; getline(cin,XuatXu);
        fflush(stdin);
        cout<< "Nhap Gia Ban:"; cin>>Price;
        fflush(stdin);
    }
    void Xuat()
    {
        cout<< "Nhan Hieu:"<<NhanHieu<< "\t";
        cout<< "Kieu Dang:"<<KieuDang<< "\t";
        cout<< "Mau Son:"<< MauSon<< "\t";
        cout<< "Nam San Xuat:"<< year<< "\t";
        cout<< "Noi San Xuat:"<<XuatXu<<"\t";
        cout<< "Gia Ban:"<<Price<<endl;
    }
    friend void Nhapds(XeHoi ds[],int n)
    {
        for(int i=0;i<n;i++)
        {
            cout<< "Nhap Thong Tin Xe Thu "<<i+1<<":"<<endl;
            ds[i].Nhap();
            cout<<endl;
        }
    }
    friend void Xuatds(XeHoi ds[],int n)
    {
        for(int i=0;i<n;i++)
        {
                ds[i].Xuat();
                cout<<endl;
        }

    }
    friend void SapXep(XeHoi ds[],int n)
    {
        for(int i=0;i<n-1;i++)
        {
            for(int j=i+1;j<n;j++)
            {
                if(ds[i].Price>ds[j].Price)
                {
                    XeHoi tem=ds[i];
                    ds[i]=ds[j];
                    ds[j]=tem;
                }
            }
        }
    }
    friend void Toyota(XeHoi ds[],int  n)
    {
        for(int i=0;i<n;i++)
        {
            if(ds[i].NhanHieu=="Toyota")
            {
                ds[i].Xuat();
            }
        }
    }
};
int main()
{
    int n;
    cout<< "Nhap So Luong Xe:"; cin>>n;
    XeHoi a[n];
    Nhapds(a,n);
    Xuatds(a,n);
    cout<< "Sap Xep Tang Dan Theo Gia:"<<endl;
    SapXep(a,n);
    Xuatds(a,n);
    cout<< "Danh Sach Xe Toyota"<<endl;
    Toyota(a,n);
    delete a;
    return 0;
}
