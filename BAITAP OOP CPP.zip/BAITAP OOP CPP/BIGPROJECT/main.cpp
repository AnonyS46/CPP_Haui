#include <iostream>
#include <string>
#include <stdio.h>
#include "iomanip"

using namespace std;
class PhieuMuaHang;
class PhieuKiem;
int n;
class Date
{
    int D,M,Y;
public:
    void Nhap()
    {
        cout<< "\n Nhap Ngay:";   cin>>D;
        cout<< "\n Nhap Thang:";  cin>>M;
        cout<< "\n Nhap Nam:";    cin>>Y;
    }
    void Xuat()
    {
        cout<<D<<"/"<<M<<"/"<<Y;
    }
    friend class PhieuMuaHang;
    friend class PhieuKiem;
};
class MatHang
{
private:
    string TenHang;
    int DonGia;
    int SoLuong;

public:
    void Nhap()
    {
        cout<< "\n Nhap Ten Hang:";    fflush(stdin);             getline(cin,TenHang);
        cout<< "\n Nhap Don Gia:";                                cin>>DonGia;
        cout<< "\n Nhap So Luong:";                               cin>>SoLuong;
    }
    int Tong=0;
    void Xuat()
    {
        cout<<setw(10)<<TenHang;
        cout<<setw(15)<<DonGia;
        cout<<setw(15)<<SoLuong;
        cout<<setw(15)<<DonGia*SoLuong;
        cout<<endl;

    }
    friend class PhieuMuaHang;
};

class PhieuMuaHang
{
private:
    string MaPhieu;
    Date Nl;
    MatHang *a;
public:

    void Nhap()
    {

        cout<< "\n Nhap Ma Phieu:";    fflush(stdin);             getline(cin,MaPhieu);
        cout<< "\n Nhap Ngay:";        fflush(stdin);             cin>>Nl.D;
        cout<< "\n Nhap Thang:";                                  cin>>Nl.M;
        cout<< "\n Nhap Nam :";                                   cin>>Nl.Y;
        cout<< "\n Nhap so luong hang hoa:";                      cin>>n;
        a=new MatHang[n];
        for(int i=0;i<n;i++)
        {
            cout<< "\n Nhap thong tin mat thu: "<<i+1<<endl;
            a[i].Nhap();
        }
        cout<<endl;
    }

    void Xuat()
    {
        int Tong=0;
        cout<<endl;
        cout<< setw(40)<<"PHIEU MUA HANG"<<endl<<endl<<endl;
        cout<<setw(5)<<"Ma Phieu: "<<MaPhieu;
        cout<<setw(40)<<"Ngay Lap: "<<Nl.D<<"/"<<Nl.M<<"/"<<Nl.Y<<endl<<endl<<endl;
        cout<<setw(10)<<"TenHang";
        cout<<setw(15)<<"DonGia";
        cout<<setw(15)<<"SoLuong";
        cout<<setw(15)<<"Thanh tien";
        cout<<endl<<endl;
        for (int i=0;i<n;i++)
        {
            a[i].Xuat();
        }

        for(int i=0;i<n;i++)
        {
            Tong+=(a[i].DonGia)*(a[i].SoLuong);
        }
        cout<<setw(50)<<"Cong Than Tien: "<<Tong;

    }
};
class PhieuBaoDiem;
class MonHoc
{
private:
    string TenMon;
    int SoTring;
    float Diem;
public:
    void Nhap()
    {
        cout<< "\n Nhap ten mon hoc:";               fflush(stdin);         getline(cin,TenMon);
        cout<< "\n Nhap so trinh cua mon hoc:";      fflush(stdin);         cin>>SoTring;
        cout<< "\n Nhap Diem Mon hoc:";              fflush(stdin);         cin>>Diem;
        cout<<endl;
    }
    void Xuat()
    {
        cout<<setw(15)<<TenMon;
        cout<<setw(20)<<SoTring;
        cout<<setw(15)<<Diem<<endl;
        cout<< "-------------------------------------------------------";
        cout<<endl;
    }
    friend class PhieuBaoDiem;
};

class PhieuBaoDiem
{
private:
    string MSV;
    string TenSV;
    string Lop;
    int Khoa;
    MonHoc *x;
public:
    int  n;
    void Nhap()
    {

        cout<< "\n Nhap Ma Sinh vien:";              fflush(stdin);          getline(cin,MSV);
        cout<< "\n Nhap Ten Sinh Vien:";             fflush(stdin);          getline(cin,TenSV);
        cout<< "\n Nhap Ten Lop:";                   fflush(stdin);          getline(cin,Lop);
        cout<< "\n Nhap Khoa:";                                              cin>>Khoa;
        cout<< "\n Nhap So Luong Mon Hoc";                                   cin>>n;
        x=new MonHoc[n];
        for(int i=0;i<n;i++)
        {
            x[i].Nhap();
        }

    }
    void Xuat()
    {
        cout<< "\n---------------------PHIEU BAO DIEM----------------------"<<endl<<endl;
        cout<<setw(5)<<"Ma Sinh Vien:"<<MSV;
        cout<<setw(7)<<"Ten Sinh Vien:"<<TenSV<<endl<<endl;
        cout<<setw(5)<<"Lop:"<<Lop;
        cout<<setw(7)<<"Khoa:"<<Khoa<<endl;
        cout<<setw(10)<<"Bang diem:"<<endl;
        cout<< "----------------------------------------------------------"<<endl<<endl;
        cout<<setw(16)<<"Ten Mon Hoc";
        cout<<setw(22)<<"So Trinh";
        cout<<setw(15)<<"Diem";
        cout<<endl;
        for(int i=0;i<n;i++)
        {
            x[i].Xuat();
        }
    }
};

class NhanVien
{
private:
    string TenNV;
    string ChucVu;
public:
    void Nhap()
    {
        cout<< "\n Nhap Ten Nhan Vien:";        fflush(stdin);             getline(cin,TenNV);
        cout<< "\n Nhap Chuc vu:";              fflush(stdin);             getline(cin,ChucVu);

    }
    void Xuat()
    {
        cout<<setw(5)<<"Nhan Vien Kiem Ke:"<<TenNV;
        cout<<setw(20)<<"Chuc Vu:"<<ChucVu;
    }
    friend class PhieuKiem;
};
class PhongKiemKe
{
private:
    string TenPhong;
    string MaPhong;
    string TruongPhong;
public:
    void Nhap()
    {
        cout<< "\n Nhap Ten Phong:";         fflush(stdin);                getline(cin,TenPhong);
        cout<< "\n Nhap Ma Phong:";          fflush(stdin);                getline(cin,MaPhong);
        cout<< "\n Nhap Ten Truong Phong:";  fflush(stdin);                getline(cin,TruongPhong);
    }
    void Xuat()
    {
        cout<<setw(5)<<"Kiem Ke Tai Phong:"<<TenPhong;
        cout<<setw(20)<<"Ma Phong:"<<MaPhong<<endl;
        cout<<setw(5)<<"Truong Phong:"<<TruongPhong;
        cout<<endl;
    }
    friend class PhieuKiem;


};
class TaiSan
{
private:
    string TenTs;
    int SoLuong;
    string TinhTrang;
public:
    void Nhap()
    {
        cout<< "\n Nhap Ten Tai San:";               fflush(stdin);           getline(cin,TenTs);
        cout<< "\n Nhap So Luong:";                                           cin>>SoLuong;
        cout<< "\n Nhap Tinh Trang:";                fflush(stdin);           getline(cin,TinhTrang);
    }
    void Xuat()
    {
        cout<<setw(5)<<TenTs;
        cout<<setw(20)<<SoLuong;
        cout<<setw(20)<<TinhTrang;
        cout<< "\n-----------------------------------------------------------";
        cout<<endl;
    }
    friend class PhieuKiem;
};
class PhieuKiem
{
private:
    string MaPhieu;
    Date ns;
    NhanVien x;
    TaiSan *a;
    PhongKiemKe k;
public:
    int n;
    void Nhap()
    {
        cout<< "\n Nhap Ma Phieu:";             fflush(stdin);          getline(cin,MaPhieu);
        ns.Nhap();
        x.Nhap();
        k.Nhap();
        cout<< "\n Nhap So Luong Tai San:";       cin>>n;
        a=new TaiSan[n];
        for(int i=0;i<n;i++)
        {
            cout<< "\n Nhap Thong Tin Tai San Thu: "<<i+1<<endl;
            a[i].Nhap();
        }
    }
    void Xuat()
    {
        cout<< "=====================PHIEU KIEM KE TAI SAN===================\n"<<endl;
        cout<<setw(5)<<"Ma Phieu:"<<MaPhieu;
        cout<<setw(20)<<"Ngay Kiem Ke:";
        ns.Xuat();
        cout<<endl;
        cout<<endl;
        x.Xuat();
        cout<<endl;
        cout<<endl;
        k.Xuat();
        cout<< "\n-----------------------------------------------------------"<<endl;
        cout<<setw(5)<<"Ten Tai San";
        cout<<setw(25)<<"So Luong";
        cout<<setw(20)<<"TinhTrang";
        cout<< "\n-----------------------------------------------------------";
        cout<<endl;
        for(int i=0;i<n;i++)
        {
            a[i].Xuat();
        }

    }

};
int main()
{

    PhieuKiem a;
    a.Nhap();
    a.Xuat();
    /*
    PhieuBaoDiem a;
    a.Nhap();
    a.Xuat();
    PhieuMuaHang a;
    a.Nhap();
    a.Xuat(); */
    return 0;
}
