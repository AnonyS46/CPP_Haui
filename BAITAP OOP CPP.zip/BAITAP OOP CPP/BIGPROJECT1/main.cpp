#include <iostream>
#include <string>
#include <stdio.h>
#include "iomanip"

using namespace std;
class School;
class Faculty;
class Date{

    int d,m,y;
public:
    void Nhap()
    {
        cout<< "\n Nhap ngay:";        cin>>d;
        cout<< "\n Nhap thang:";       cin>>m;
        cout<< "\n Nhap nam:";         cin>>y;
    }
    void Xuat()
    {

        cout<<d<<"/"<<m<<"/"<<y;
    }
    friend class School;

};
class School
{

    string name;
    Date ntl;
public:
    friend class Faculty;
};
class Faculty
{
private:
    string name;
    Date ngay;
    School x;
public:
    void Nhap()
    {

        cout<< "\n Nhap ten khoa:";           fflush(stdin);             getline(cin,name);
        cout<< "\n Nhap ngay thanh lap khoa:"<<endl;
        ngay.Nhap();
        cout<< "\n Nhap ten truong:";         fflush(stdin);             getline(cin,x.name);
        cout<< "\n Nhap ngay thanh lap truong:"<<endl;
        x.ntl.Nhap();
    }
    void Xuat()
    {
        cout<< "\n Ten khoa: "<<name;
        cout<< "\n Ngay thanh lap khoa:";
        ngay.Xuat();
        cout<< "\n Ten truong:"<<x.name;
        cout<< "\n Ngay thanh lap truong:";
        x.ntl.Xuat();
    }
};
class Person
{
protected:
    string name;
    Date birth;
    string address;
public:
    void Nhap()
    {
        cout<< "\n Nhap ten:";                fflush(stdin);              getline(cin,name);
        cout<< "\n Nhap ngay sinh:";
        birth.Nhap();
        cout<< "\n Nhap dia chi:";            fflush(stdin);              getline(cin,address);
    }
    void Xuat()
    {
        cout<< "\n Ten:"<<name;
        cout<< "\n Ngay sinh"
    }
};
int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
