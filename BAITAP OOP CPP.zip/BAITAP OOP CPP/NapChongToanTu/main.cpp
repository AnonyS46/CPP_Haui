#include <iostream>
#include <math.h>

using namespace std;
class TamThuc
{
private:
    int a,b,c;
public:
    TamThuc()
    {
        a=0;
        b=0;
        c=0;
    }
     TamThuc(int a,int b,int c)
    {
        this->a=a;
        this->b=b;
        this->c=c;
    }
friend ostream &operator <<(ostream &os,TamThuc k)
    {
        cout<< k.a<<"x2"<<"+"<<k.b<<"x"<<"+"<<k.c;
        return os;
    }
    friend TamThuc &operator *(TamThuc &k,int n)
    {
        k.a=k.a*n;
        k.b=k.b*n;
        k.c=k.c*n;
        return k;
    }
    friend TamThuc operator+(TamThuc k1,TamThuc k2)
    {
        TamThuc x;
        x.a=k1.a+k2.a;
        x.b=k1.b+k2.b;
        x.c=k1.c+k2.c;
        return x;
    }
    ~TamThuc()
    {

    }
};
int main()
{
    TamThuc a(1,2,4);
    TamThuc b(1,4,2);
    TamThuc c=a+b;
    cout<<a<<endl;
    cout<<a*-1<<endl;
    cout<<c;
    return 0;
}
