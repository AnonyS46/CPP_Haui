#include <iostream>
#include <string>
#include <stdio.h>
#include "iomanip"

using namespace std;

class Date
{
public:
    int day;
    int month;
    int year;
public:
    friend class NhanVien;


};
class PhongBan
{
public:
    int MaPB;
    string tenPB;
    string truongPhong;
    int SoNV;
public:
    friend class NhanVien;

};
class NhanVien
{
private:
    int maNV;
    string  HoDem;
    string ten;
    Date ns;
    PhongBan Phong;
public:
    friend class Date;
    friend class PhongBan;
    NhanVien()
    {
        maNV=0;
        HoDem="";
        ten="";
        ns.day=0;
        ns.month=0;
        ns.year=0;
        Phong.MaPB=0;
        Phong.SoNV=0;
        Phong.tenPB="";
        Phong.truongPhong="";
    }
    void Nhap();
    void Xuat();
    friend void SapXep(NhanVien *,int n);
    friend void Chen(NhanVien *,int &);
    ~NhanVien()
    {

    }

};
void NhanVien::Nhap()
{
	cout<< "\n Nhap Ma Nhan Vien:";                               cin>>maNV;
	cout<< "\n Nhap Ho Dem Nhan Vien:";      fflush(stdin);       getline(cin,HoDem);
	cout<< "\n Nhap Ten Nhan Vien:";         fflush(stdin);       getline(cin,ten);
	cout<< "\n Nhap Ngay Sinh:" ;                                 cin>>ns.day;
	cout<< "\n Nhap Thang Sinh:" ;                                cin>>ns.month;
	cout<< "\n Nhap Nam Sinh:" ;                                  cin>>ns.year;
	cout<< "\n Nhap Ma Phong Ban:";                               cin>>Phong.MaPB;
	cout<< "\n Nhap Ten Phong Ban:";          fflush(stdin);      getline(cin,Phong.tenPB);
	cout<< "\n Nhap Ten Truong Phong:";       fflush(stdin);      getline(cin,Phong.truongPhong);
	cout<<endl;
}
void NhanVien::Xuat()
{
    cout<<setw(10)<<maNV;
    cout<<setw(15)<<HoDem;
    cout<<setw(8)<<ten;
    cout<<setw(8)<<ns.day<<"/"<<ns.month<<"/"<<ns.year;
    cout<<setw(20)<<Phong.MaPB;
    cout<<setw(20)<<Phong.tenPB;
    cout<<setw(25)<<Phong.truongPhong;
    cout<<endl;
}
void SapXep(NhanVien *a,int n)
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(a[i].ten.compare(a[j].ten)>0)
            {
                swap(a[i],a[j]);
            }
        }
    }
}
void  Chen(NhanVien *a,int &n)
{
    int k;
    NhanVien x;
    cout<< "\n Nhap thong tin Nhan vien can chen:"<<endl;
    x.Nhap();
    cout<< "\n Nhap vi tri can chen:"; cin>>k; k--; fflush(stdin);

//  1  2  3   4

    for(int i=n;i>k;i--)
    {
        a[i]=a[i-1];
    }
    a[k]=x;
    n++;


}
int main()
{
    NhanVien *a;
    int n;
    cout<< " Nhap So Nhan Vien:";   cin>>n;
    a=new NhanVien[n];
    for(int i=0;i<n;i++)
    {
        cout<< "\n Nhap thong tin Nhan Vien thu: "<<i+1<<endl;
        a[i].Nhap();
    }
    //Xuat tieu de
    cout<<setw(10)<<"Ma NV";
    cout<<setw(15)<<"Ho Dem";
    cout<<setw(8)<<"Ten";
    cout<<setw(15)<<"Ngay Sinh";
    cout<<setw(20)<<"Ma Phong Ban";
    cout<<setw(20)<<"Ten Phong Ban";
    cout<<setw(25)<<"Ten Truong Phong";
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        a[i].Xuat();
    }
    SapXep(a,n);
    cout<< "\n Thong Tin Sau Khi Sap Xep:"<<endl;
    for(int i=0;i<n;i++)
    {
        a[i].Xuat();
    }
    Chen(a,n);
    cout<< "\n Thong Tin Sau Khi chen:"<<endl;
    for(int i=0;i<n;i++)
    {
        a[i].Xuat();
    }
     delete a;
    return 0;
}
