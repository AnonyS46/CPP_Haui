#include <iostream>
#include <stdio.h>
#include <string>
#include "iomanip"

using namespace std;

class SanPham
{
protected:

    string  MaSP;
    string TenSp;
    int Ngaysx;
    int Thangsx;
    int Namsx;
    float TrongLuong;
    string MauSac;
public:
        virtual void Nhap()
        {
            cout<< "\n Nhap ma san pham:";  fflush(stdin);      getline(cin,MaSP);
            cout<< "\n Nhap ten san pham:"; fflush(stdin);      getline(cin,TenSp);
            cout<< "\n Nhap ngay san xuat:";                     cin>>Ngaysx;
            cout<< "\n Nhap Thang san xuat:";                   cin>>Thangsx;
            cout<< "\n Nhap Nam san xuat:";                     cin>>Namsx;
            cout<< "\n Nhap trong luong sp:";                   cin>>TrongLuong;
            cout<< "\n Nhap Mau sac sp:";    fflush(stdin);     getline(cin,MauSac);
            cout<<endl;
        }
      virtual  void Xuat()
        {
            cout<<setw(10)<<MaSP;
            cout<<setw(13)<<TenSp;
            cout<<setw(15)<<Ngaysx<<"/"<<Thangsx<<"/"<<Namsx;
            cout<<setw(15)<<TrongLuong;
            cout<<setw(10)<<MauSac;
            cout<<endl;
        }
};
class HangDienTu:public SanPham
{
   int CongSuat;
   int LoaiDien;
   public:
        void Nhap()  override
        {
            cout<< "\n Nhap ma san pham:";  fflush(stdin);      getline(cin,MaSP);
            cout<< "\n Nhap ten san pham:"; fflush(stdin);      getline(cin,TenSp);
            cout<< "\n Nhap ngay san xuat:";                     cin>>Ngaysx;
            cout<< "\n Nhap Thang san xuat:";                   cin>>Thangsx;
            cout<< "\n Nhap Nam san xuat:";                     cin>>Namsx;
            cout<< "\n Nhap trong luong sp:";                   cin>>TrongLuong;
            cout<< "\n Nhap Mau sac sp:";    fflush(stdin);     getline(cin,MauSac);
            cout<< "\n Nhap Cong suat tieu thu:";               cin>>CongSuat;
            cout<< "\n Nhap loai dien:";                        cin>>LoaiDien;
            cout<<endl;
        }
         void Xuat() override
        {
            cout<<setw(10)<<MaSP;
            cout<<setw(13)<<TenSp;
            cout<<setw(15)<<Ngaysx<<"/"<<Thangsx<<"/"<<Namsx;
            cout<<setw(15)<<TrongLuong;
            cout<<setw(10)<<MauSac;
            cout<<setw(10)<<CongSuat;
            cout<<setw(10)<<LoaiDien<< " chieu";
            cout<<endl;
        }
       friend   void ShowMin(HangDienTu *a,int n)
         {
             int Min=a[0].CongSuat;
             for(int i=0;i<n;i++)
             {
                 if(a[i].CongSuat<Min)
                 {
                     Min=a[i].CongSuat;
                 }
             }
             for(int i=0;i<n;i++)
             {
                 if(a[i].CongSuat==Min)
                 {
                     a[i].Xuat();
                 }
             }
         }

};
void XuatTieuDe()
{
            cout<<setw(10)<<"MaSP";
            cout<<setw(13)<<"TenSp";
            cout<<setw(20)<<"Ngaysx";
            cout<<setw(20)<<"TrongLuong";
            cout<<setw(10)<<"MauSac";
            cout<<setw(10)<<"CongSuat";
            cout<<setw(14)<<"LoaiDien";
            cout<<endl;
}
class SinhVien
{
public:
    string Hoten;
    string SBD;
public:
    void Xuat();
friend class KetQua;


};
class DiemThi : public SinhVien
{
public:
    float kq1;
    float kq2;
public:

   friend class KetQua;
};
class KetQua : public SinhVien
{
    DiemThi kq;

public:
    void Nhap()
    {
        cout<< "\n Nhap Ho ten:";        fflush(stdin);     getline(cin,Hoten);
        cout<< "\n Nhap So Bao Danh:";   fflush(stdin);     getline(cin,SBD);
        cout<< "\n Nhap Diem thi mon 1:";                   cin>>kq.kq1;
        cout<< "\n Nhap diem thi mon 2:";                   cin>>kq.kq2;
    }
    void Xuat();


};
void KetQua::Xuat() {
       cout<<setw(10)<<SBD;
       cout<<setw(15)<<Hoten;
       cout<<setw(10)<<kq.kq1;
       cout<<setw(10)<<kq.kq2;
       cout<<setw(10)<<kq.kq1+kq.kq2;
       cout<<endl;
}
class BenhNhan
{
protected:
    string HoTen;
    string QueQuan;
    int NamSinh;
public:
    void Nhap()
    {
        cout<< "\n Nhap Ho trn benh nhan:";       fflush(stdin);      getline(cin,HoTen);
        cout<< "\n Nhap Que Quan:";               fflush(stdin);      getline(cin,QueQuan);
        cout<< "\n Nhap Nam Sinh";                                    cin>>NamSinh;
    }
   void Xuat()
    {
        cout<<setw(10)<<HoTen;
        cout<<setw(15)<<QueQuan;
        cout<<setw(10)<<NamSinh;
    }

};
class BenhAn: public BenhNhan
{
protected:
    string TenBenhAn;
    int TienVienPhi;
public:
    void Nhap()
    {
        cout<< "\n Nhap Ho ten benh nhan:";       fflush(stdin);      getline(cin,HoTen);
        cout<< "\n Nhap Que Quan:";               fflush(stdin);      getline(cin,QueQuan);
        cout<< "\n Nhap Nam Sinh:";                                    cin>>NamSinh;
        cout<< "\n Nhap Ten Benh An:";            fflush(stdin);      getline(cin,TenBenhAn);
        cout<< "\n Nhap Tien vien phi:";                              cin>>TienVienPhi;
        cout<<endl;
    }
    void Xuat()
    {
        cout<<setw(10)<<HoTen;
        cout<<setw(15)<<QueQuan;
        cout<<setw(10)<<NamSinh;
        cout<<setw(10)<<2020-NamSinh;
        cout<<setw(15)<<TenBenhAn;
        cout<<setw(13)<<TienVienPhi;
        cout<<endl;
    }
    friend void Up10Years(BenhAn *a,int n);
};
void Up10Years(BenhAn *a,int n)
{
    for(int i=0;i<n;i++)
    {
        if((2020-a[i].NamSinh)<=10)
        {
            a[i].Xuat();
        }
    }
}
int main()
{
    BenhAn *a;
    int n;
    cout<< "Nhap So Ho so benh An:"; cin>>n;
    a=new BenhAn[n];
    for(int i=0;i<n;i++)
    {
        cout<< "\n Nhap thong tin ho so benh an thu: "<<i+1<<endl;
        a[i].Nhap();
    }
        cout<<setw(10)<<"HoTen";
        cout<<setw(15)<<"QueQuan";
        cout<<setw(13)<<"NamSinh";
        cout<<setw(10)<<"Tuoi";
        cout<<setw(15)<<"TenBenhAn";
        cout<<setw(13)<<"TienVienPhi";
        cout<<endl;
    for(int i=0;i<n;i++)
    {
        a[i].Xuat();
    }
    cout<< "\n Danh sach nhung benh nhn duoi 10 tuoi:"<<endl;
    Up10Years(a,n);
    delete a;
    /*
    HangDienTu *a;
    int n;
    cout<< " Nhap so luong hang:";  cin>>n;
    a=new HangDienTu[n];
    for(int i=0;i<n;i++)
    {
        a[i].Nhap();
    }
    XuatTieuDe();
    for(int i=0;i<n;i++)
    {
        a[i].Xuat();
    }
    ShowMin(a,n);
    KetQua *a;
    int n;
    cout<< "\n Nhap so luong sinh vien:";   cin>>n;
    a=new KetQua[n];
    for (int i=0;i<n;i++)
    {
        cout<< "\n Nhap thong tin sinh vien thu: "<<i+1;
        a[i].Nhap();

    }
    for(int i=0;i<n;i++)
    {
        a[i].Xuat();
    }
    delete a; */
    return 0;
}
