#include <iostream>
#include <string>
#include <stdio.h>
#include "iomanip"

using namespace std;
class Person
{
protected:
    string Fullname;
    int D;
    int M;
    int Y;
    string QueQuan;
    public:


};
class KySu:private Person
{
private:
    string Nganh;
    int NamTN;
public:
    virtual void Nhap()
    {
        cout<< "\n Nhap Ho va Ten Ky Su:";   fflush(stdin);    getline(cin,Fullname);
        cout<< "\n Nhap Ngay sinh:";                           cin>>D;
        cout<< "\n Nhap Thang Sinh:";                          cin>>M;
        cout<< "\n Nhap Nam Sinh:";                            cin>>Y;
        cout<< "\n Nhap Que Quan:";          fflush(stdin);    getline(cin,QueQuan);
        cout<< "\n Nhap Nganh Hoc:";         fflush(stdin);    getline(cin,Nganh);
        cout<< "\n Nhap Nam Tot Nghiep:";                      cin>>NamTN;
        cout<<endl;

    }
    void Xuat()
    {
        cout<<setw(10)<<Fullname;
        cout<<setw(15)<<D<<"/"<<M<<"/"<<Y;
        cout<<setw(10)<<QueQuan;
        cout<<setw(10)<<Nganh;
        cout<<setw(10)<<NamTN;
        cout<<endl;
    }
};
class Printer
{
protected:
    int TrongLuong;
    string HangSX;
    int NamSX;
    int TocDo;

};
class DotPrinter : public Printer
{
    int MatDoKim;
public:
    void Nhap()
    {
        cout<< "\n Nhap trong luong:";                            cin>>TrongLuong;
        cout<< "\n Nhap Hang san xuat:";     fflush(stdin);       getline(cin,HangSX);
        cout<< "\n Nhap Nam san xuat:";      fflush(stdin);       cin>>NamSX;
        cout<< "\n Nhap toc do:";                                 cin>>TocDo;
        cout<< "\n Nhap Mat do kim:";                              cin>>MatDoKim;
    }
    void Xuat()
    {
        cout<< "\n Trong luong:"<<TrongLuong;
        cout<< "\n Hang san xuat:"<<HangSX;
        cout<< "\n Nam san xuat:"<<NamSX;
        cout<< "\n Toc Do: "<<TocDo<<" trang/phut";
        cout<< "\n Mat do kim:"<<MatDoKim;
        cout<<endl;
    }
};
class LaserPrinter: public Printer
{
    string DoPhanGiai;
public:
    void Nhap()
    {
        cout<< "\n Nhap trong luong:";                            cin>>TrongLuong;
        cout<< "\n Nhap Hang san xuat:";     fflush(stdin);       getline(cin,HangSX);
        cout<< "\n Nhap Nam san xuat";                            cin>>NamSX;
        cout<< "\n Nhap toc do:";                                 cin>>TocDo;
        cout<< "\n Nhap Do phan giai:";      fflush(stdin);       getline(cin,DoPhanGiai);
    }
    void Xuat()
    {
        cout<< "\n Trong luong:"<<TrongLuong;
        cout<< "\n Hang san xuat:"<<HangSX;
        cout<< "\n Nam san xuat:"<<NamSX;
        cout<< "\n Toc Do: "<<TocDo<<" trang/phut";
        cout<< "\n Do phan giai:"<<DoPhanGiai;
        cout<<endl;

    }
};
class Electronic
{
protected:
    int CongSuat;
    int DienAp;
public:
    Electronic()
    {
        this->CongSuat=0;
        this->DienAp=0;
    }
};
class MayGiat : public Electronic
{
    int DungTich;
    string Loai;
public:
    MayGiat(int DienAp,int CongSuat,int DungTich,string Loai)
    {
       this->CongSuat=CongSuat;
       this->DienAp=DienAp;
       this->DungTich=DungTich;
       this->Loai=Loai;

    }
    void Xuat()
    {
        cout<< "\n Cong Suat:"<<CongSuat;
        cout<< "\n Dien Ap:"<<DienAp;
        cout<< "\n Dung Tich:"<<DungTich;
        cout<< "\n Loai:"<<Loai;
        cout<< endl;
    }
};
class TuLanh : public Electronic
{
    int DungTich;
    int SoNgan;
public:
    TuLanh(int CongSuat,int DienAp,int DungTich,int SoNgan)
    {
       this->CongSuat=CongSuat;
       this->DienAp=DienAp;
       this->DungTich=DungTich;
       this->SoNgan=SoNgan;
    }
    void Xuat()
    {
        cout<< "\n Cong Suat:"<<CongSuat;
        cout<< "\n Dien Ap:"<<DienAp;
        cout<< "\n Dung Tich:"<<DungTich;
        cout<< "\n So Ngan:"<<SoNgan;
        cout<< endl;
    }
};
class ThucPham
{
protected:
    string Name;
    long Price;
};
class TpHop:public ThucPham
{
    int SoHop;
public:
    void Nhap()
    {
        cout<< "\n Nhap ten thuc pham:";     fflush(stdin);   getline(cin,Name);
        cout<< "\n Nhap Gia Sp:";                             cin>>Price;
        cout<< "\n Nhap So hop:";                             cin>>SoHop;

    }
    void Xuat()
    {
        cout<< "\n Ten:"<<Name;
        cout<< "\n Gia:"<<Price;
        cout<< "\n So Hop:"<<SoHop;
        cout<<endl;
    }

};
class TpKHop : public ThucPham
{
    int KhoiLuong;
public:
    void Nhap()
    {
        cout<< "\n Nhap ten thuc pham:";     fflush(stdin);   getline(cin,Name);
        cout<< "\n Nhap Gia Sp:";                             cin>>Price;
        cout<< "\n Nhap Khoi Luong:";                         cin>>KhoiLuong;

    }
    void Xuat()
    {
        cout<< "\n Ten:"<<Name;
        cout<< "\n Gia:"<<Price;
        cout<< "\n Khoi Luong:"<<KhoiLuong;
        cout<<endl;
    }
};
int main()
{
   /* DotPrinter a;
    LaserPrinter b;
    //Nhap may  kim
    cout<< "\n Nhap thong tin may kim:"<<endl;
    a.Nhap();
    cout<< "\ Nhap thong tin may laser:"<<endl;
    b.Nhap();
    //Xuat thong tin may kim
    cout<< "\n Thong tin may kim:"<<endl;
    a.Xuat();
    cout<< "\n Thong tin may laser:"<<endl;
    b.Xuat();
    MayGiat a(200,220,50,"ToSiBa");
    TuLanh b(100,220,120,4);
    a.Xuat();
    b.Xuat(); */
    TpHop a;
    TpKHop b;
    cout<< "\n Nhap thong tin sp co hop:"<<endl;
    a.Nhap();
    cout<< "\n Nhap thong tin sp khong hop:"<<endl;
    b.Nhap();
    cout<< "\n Thong tin sp co hop:"<<endl;
    a.Xuat();
    cout<< "\n Thong tin san pham khong hop:"<<endl;
    b.Xuat();
    return 0;
}
