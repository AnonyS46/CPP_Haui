#include <iostream>
#include <string>
#include <string.h>
#include<stdio.h>
using namespace std;
class PhongMay;
class QuanLy
{
private:
    string MaQl;
    string HoTen;
public:
    void Nhap()
    {
        fflush(stdin);
        cout<< "Nhap Ma Quan Ly:"; getline(cin,MaQl);
        fflush(stdin);
        cout<< "Nhap Ho Ten:"; getline(cin,HoTen);
    }
    void Xuat()
    {
        cout<< "Ma Quan Ly:"<<MaQl<< "\t" ;
        cout<< "Ho Ten:"<<HoTen<<"\t"<<endl ;
    }
    friend class PhongMay;
};
class May
{
private:
    string MaMay;
    string KieuMay;
    string TinhTrang;
public:
    void Nhap()
    {
        fflush(stdin);
        cout<< "Nhap Ma May:"; getline(cin,MaMay);
        fflush(stdin);
        cout<< "Nhap Kieu May:"; getline(cin,KieuMay);
        fflush(stdin);
        cout<< "Nhap Tinh Trang May:"; getline(cin,TinhTrang);
    }
    void Xuat()
    {
        cout<< "Ma May:"<<MaMay<< "\t";
        cout<< "Kieu May:"<<KieuMay<< "\t";
        cout<< "Tinh trang:"<<TinhTrang<< "\t"<<endl;
    }
    friend class PhongMay;
};
class  PhongMay
{
private:
    string MaPhong;
    string TenPhong;
    QuanLy x;
    May *y;

public:
    int n;
    void Nhap()
    {
        fflush(stdin);
        cout<< "Nhap Ma Phong:"; getline(cin,MaPhong);
        fflush(stdin);
        cout<< "Nhap Ten Phong:"; getline(cin,TenPhong);
        cout<< "Nhap thong  tin quan ly"<<endl;
        x.Nhap();
        cout<< "Nhap so luong may:"; cin>>n;
        y=new May[n];
        for(int i=0;i<n;i++)
        {
            cout<< "Nhap thong tin may thu: "<<i+1<<endl;
            y[i].Nhap();
        }
    }
    void Xuat()
    {
        cout<< "Ma Phong:"<<MaPhong<< "\t";
        cout<< "Ten Phong:"<<TenPhong<<endl;
        x.Xuat();
        for(int i=0;i<n;i++)
        {
            y[i].Xuat();
        }
    }
};
class NhanSu;
class Date
{
private:
    int D;
    int M;
    int Y;
public:
    void Nhap()
    {
        cout<< "Nhap ngay:"; cin>>D;
        cout<< "Nhap thang:"; cin>>M;
        cout<< "Nhap nam:";  cin>>Y;
    }
    void Xuat()
    {
        cout<< "Ngay Sinh:"<<D<< "/"<<M<<"/"<<Y;
    }
    friend class NhanSu;
    friend void SapXep(NhanSu *,int n);
};
class  NhanSu
{
private:
    string Hoten;
    Date ns;
    string Cmnd;
public:
    void Nhap()
    {
        fflush(stdin);
        cout<< "Nhap ho ten:";  getline(cin,Hoten);
        cout<< "Nhap ngay sinh:"<<endl;
        ns.Nhap();
        fflush(stdin);
        cout<< "Nhap so CMND:"; getline(cin,Cmnd);
    }
    void Xuat()
    {
        cout<< "Ho ten:"<<Hoten<< "\t";
        ns.Xuat();
        cout<< "\t";
        cout<< "So CMND:"<<Cmnd<<endl;
    }
   friend void SapXep(NhanSu *,int n);
};
void SapXep(NhanSu *a,int n)
{
  for(int i=0;i<n-1;i++)
  {
      for(int j=i+1;j<n;j++)
      {
          if(a[i].Hoten.compare(a[j].Hoten)>0)
          {
              NhanSu temp=a[i];
              a[i]=a[j];
              a[j]=temp;
          }
      }

  }
}
class Array
{
private:
    int *value;
    int n;
public:
    Array()
    {

        n=0;
    }
    Array(int q)
    {

        n=q;
        value=new int[n]();


    }
    void Nhap()
    {
        for(int i=0;i<n;i++)
        {
            cout<< "Nhap value["<<i<<"]="; cin>>value[i];
            cout<<endl;
        }
    }
    void Xuat()
    {
        for(int i=0;i<n;i++)
        {
            cout<< value[i]<< "\t";
        }
    }
    ~Array()
    {

        n=0;
        delete value;
    }
};
int main()
{
   /* PhongMay a;
    a.Nhap();

    a.Xuat();
    int n;
    cout<< "Nhap so nhan  su:"; cin>>n;
    NhanSu *a;
    a=new NhanSu[n];
    for(int i=0;i<n;i++)
    {
        a[i].Nhap();
    }
    for(int i=0;i<n;i++)
    {
       a[i].Xuat();
    }
    SapXep(a,n);
    cout<< "Sau khi sap xep:"<<endl;
    for(int i=0;i<n;i++)
    {
       a[i].Xuat();
    }
    delete a;
    */


    Array a(4);
    a.Nhap();
    a.Xuat();
    return 0;
}
